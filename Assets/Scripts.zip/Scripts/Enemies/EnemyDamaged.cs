using UnityEngine;
using System.Collections;

namespace CyberVeil.Enemies
{
    [RequireComponent(typeof(EnemyAIController))]
    public class EnemyDamaged : MonoBehaviour
    {
        [Header("Damaged Settings")]
        [SerializeField] private float damagedDuration = 0.5f;
        public bool isStaggered = false;

        private EnemyAIController enemyAI;

        private void Start()
        {
            enemyAI = GetComponent<EnemyAIController>();
        }

        public void TriggerDamage()
        {
            if (enemyAI.currentAIState != EnemyAIState.Damaged) return;

            if (!isStaggered)
            {
                StartCoroutine(HandleDamaged());
            }
        }

        private IEnumerator HandleDamaged()
        {
            isStaggered = true;
            yield return new WaitForSeconds(damagedDuration);
            isStaggered = false;
        }
    }
}
